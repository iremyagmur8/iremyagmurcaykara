@extends('layouts.app')
@section('title','')
@section('desc','')
@section('content')
    <main class="main-content" id="main-content">
        @isset($cData->place[1])
            <section
                class="position-relative rounded-bottom-start-block bg-shade-dark text-white jarallax overflow-hidden"
                data-jarallax=".3" id="hero">
                <!--Parallax background-->
                <img
                    src="https://images.pexels.com/photos/3737594/pexels-photo-3737594.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                    class="jarallax-img opacity-50" alt="">
                <!--Connected line-->
                <div class="position-absolute star-0 bottom-0 w-100 text-center justify-content-center text-muted">
                    <div class="connect-line d-inline-block position-relative"></div>
                </div>
                <div class="container position-relative z-index-1">
                    <div class="row vh-100 d-flex align-items-center justify-content-center text-center">
                        <div class="col-xl-11">
                            @isset($cData->place[1][0]->buttontext)
                                @php
                                    $texts=explode(",",$cData->place[1][0]->buttontext);
                                    $f=0;
                                @endphp
                                <h2 class="mb-5 display-1">{{nl2br($cData->place[1][0]->title)}}
                                    <span class="d-inline-block text-warning"
                                          data-typed='{"strings": [ @foreach($texts as $key=>$val) "{{$val}}"@if($loop->last) @else , @endif  @php($f++) @endforeach]}'></span>
                                </h2>
                            @endisset
                            @isset($cData->place[1][0]->shortdescription)  <p
                                class="mb-6 lead">{{$cData->place[1][0]->shortdescription}}</p> @endisset
                            <div class="">
                                <a href="#!" class="btn btn-white btn-lg btn-hover-text">
                                    <span class="btn-hover-label label-default">Daha Fazlası İçin</span>
                                    <span class="btn-hover-label label-hover">Daha Fazlası İçin</span>
                                </a>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
        @endisset
        @isset($cData->place[2])
            <section>
                <div class="container py-lg-11 py-9">
                    <div class="row align-items-center">
                        <div class="col-lg-5 mb-7 mb-lg-0">
                            @isset($cData->place[2][0]->title)
                                <h2 class="display-4 mb-4" data-aos="fade-up">
                                    {{$cData->place[2][0]->title}}
                                </h2>
                            @endisset
                            @isset($cData->place[2][0]->description)
                                <p class="mb-5 font-serif" data-aos="fade-up">
                                    {!! $cData->place[2][0]->description !!}
                                </p>
                            @endisset
                            <div class="d-flex flex-column flex-md-row align-items-md-center" data-aos="fade-up">
                                @isset($cData->place[2][0]->buttontext)
                                    <span class="me-md-4 mb-3 mb-md-0">
                                    <a href="tel:{{$vars->contact->phone}}"
                                       class="btn btn-primary">{{$cData->place[2][0]->buttontext}}</a>
                                </span>
                                @endisset
                            </div>
                        </div>
                        <div class="col-lg-6 ms-auto">
                            <div class="position-relative pe-7 pb-7" data-aos="fade-up">
                                <div
                                    class="width-15x height-15x bg-warning rounded-pill position-absolute end-0 top-0 mt-7"></div>
                                <div
                                    class="width-1x height-1x bg-success rounded-pill position-absolute start-0 bottom-0 ms-9 mb-4"></div>
                                <div
                                    class="position-absolute end-0 bottom-0 h-50 w-50 rounded-4 shadow-lg bg-white"></div>
                                <img
                                    src="https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                                    class="rounded-4 position-relative img-fluid" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        @endisset
        <section class="position-relative overflow-hidden">

            <!--Content container-->
            <div class="container py-9 py-lg-11 position-relative">
                <div class="row align-items-center">

                    @isset($cData->place[3])
                        <div
                            class="col-lg-6 col-xl-5 ps-lg-7 ps-5 pb-4 order-lg-last me-lg-auto mb-5 mb-lg-0 position-relative"
                            data-aos="fade-down">
                            <div
                                class="bg-pattern text-warning position-absolute w-50 h-50 mb-lg-n4 mb-n2 start-0 bottom-0">
                            </div>
                            <div
                                class="position-relative bg-white rounded-4 rounded-bottom-start-0 rounded-top-end-0 shadow-lg overflow-hidden">
                                <div class="position-relative bg-white overflow-hidden">
                                    <!--Get started image divider shape-->
                                    <svg class="position-absolute start-0 bottom-0 flip-y" width="100%" height="24"
                                         preserveAspectRatio="none" viewBox="0 0 1284 100" fill="none"
                                         xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                              d="M0 0L31.03 14.5833C60.99 29.1667 121.98 58.3333 182.97 62.5C245.03 66.6667 306.02 45.8333 367.01 35.4167C428 25 488.99 25 549.98 37.5C610.97 50 673.03 75 734.02 70.8333C795.01 66.6667 856 33.3333 916.99 31.25C977.98 29.1667 1038.97 58.3333 1101.03 75C1162.02 91.6667 1223.01 95.8333 1252.97 97.9167L1284 100V0H1252.97C1223.01 0 1162.02 0 1101.03 0C1038.97 0 977.98 0 916.99 0C856 0 795.01 0 734.02 0C673.03 0 610.97 0 549.98 0C488.99 0 428 0 367.01 0C306.02 0 245.03 0 182.97 0C121.98 0 60.99 0 31.03 0H0Z"
                                              fill="white"/>
                                    </svg>
                                    <!--Get started image-->
                                    <img
                                        src="https://images.pexels.com/photos/819808/pexels-photo-819808.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                                        class="img-fluid" alt="">
                                </div>
                                <div class="px-4 bg-white position-relative pb-5 pt-4">
                                    @isset($cData->place[3][0]->shortdescription)
                                        <small
                                            class="d-block mb-2 text-muted">{{$cData->place[3][0]->shortdescription}}</small>
                                    @endisset
                                    @isset($cData->place[3][0]->title)
                                        <h5 class="mb-4">{{$cData->place[3][0]->title}}</h5>
                                    @endisset
                                    @isset($cData->place[3][0]->description)
                                        <p>{!! $cData->place[3][0]->description !!}</p>
                                    @endisset
                                    @isset($cData->place[3][0]->buttontext)
                                        <div class="d-grid">
                                            <button type="button"
                                                    class="btn btn-primary rounded-pill hover-shadow btn-hover-arrow hover-lift">
                                                <span>{{$cData->place[3][0]->buttontext}}</span>
                                            </button>
                                        </div>
                                    @endisset
                                </div>
                            </div>
                        </div>
                    @endisset
                    <div class="col-lg-5 order-lg-last position-relative">
                        <!--Subtitle-->
                        <div class="d-flex align-items-center mb-3" data-aos="fade-up">
                            <div class="border-top border-warning width-3x border-2"></div>
                            @isset($cData->place[4][0]->buttontext)
                                <h6 class="mb-0 ms-3 text-muted">{{$cData->place[4][0]->buttontext}}</h6>
                            @endisset
                        </div>
                        @isset($cData->place[4][0]->title)
                            <h2 class="display-5 me-lg-n9 mb-4" data-aos="fade-down">{{$cData->place[4][0]->title}}</h2>
                        @endisset
                        @isset($cData->place[4][0]->shortdescription)
                            <p class="w-lg-80 mb-5" data-aos="fade-down"
                               data-aos-delay="100">{{$cData->place[4][0]->shortdescription}}</p>
                        @endisset
                        <ul class="step mx-3 mx-sm-0 list-unstyled mb-0">
                            <? $n = 0 ?>
                            @foreach($cData->place[5] as $key=>$val)
                                <li class="step-item" data-aos="fade-up">
                                    <div class="step-row">
                                        <span class="step-icon bg-tint-primary text-primary">
                                            <b>@php($n++) {{$n}}</b>
                                        </span>

                                        <div class="step-content">
                                            @isset($val->title)
                                                <h6 class="mb-1">{{$val->title}}</h6>
                                            @endisset
                                            @isset($val->shortdescription)
                                                <p class="mb-0">{{$val->shortdescription}}</p>
                                            @endisset

                                        </div>
                                    </div>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <section class="position-relative overflow-hidden">
            <div class="container py-9 py-lg-11 position-relative z-index-1">
                <div class="row align-items-center justify-content-between">
                    <div class="order-last order-lg-1 col-lg-5">
                        @isset($cData->place[6][0]->title)
                            <h2 class="mb-3 display-4" data-aos="fade-up">{{$cData->place[6][0]->title}}
                            </h2>
                        @endisset
                        @isset($cData->place[6][0]->shortdescription)
                            <p class="mb-4 lead" data-aos="fade-up" data-aos-delay="100">
                                {{$cData->place[6][0]->shortdescription}}
                            </p>
                        @endisset

                        <div class="accordion accordion-custom mb-5" id="accordionExample" data-aos="fade-right"
                             data-aos-delay="150">
                            @isset($cData->place[7])
                                @foreach($cData->place[7] as $key=>$val)
                                    <div class="accordion-item mb-3">
                                        <h2 class="accordion-header" id="heading-{{$val->id}}">
                                            @isset($val->title)
                                                <button
                                                    class="accordion-button @if($key ==! 0 ) collapsed @endif h5 mb-0"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse-{{$val->id}}" aria-expanded="true"
                                                    aria-controls="collapse-{{$val->id}}">
                                                    {{$val->title}}
                                                </button>
                                            @endisset
                                        </h2>
                                        @isset($val->shortdescription)
                                            <div id="collapse-{{$val->id}}"
                                                 class="accordion-collapse collapse @if($key == 0 ) show @endif"
                                                 aria-labelledby="heading-{{$val->id}}"
                                                 data-bs-parent="#accordionExample">
                                                <div class="accordion-body">
                                                    {{$val->shortdescription}}
                                                </div>
                                            </div>
                                        @endisset
                                    </div>
                                @endforeach
                            @endisset
                        </div>
                        @isset($cData->place[6][0]->buttontext)
                            <div data-aos="fade-up" data-aos-delay="200">
                                <a href="#!" class="btn btn-primary hover-lift py-lg-3 px-lg-6">
                                    {{$cData->place[6][0]->buttontext}}
                                </a>
                            </div>
                        @endisset
                    </div>
                    <div class="col-lg-6 ms-auto order-1 order-lg-last mb-5 mb-lg-0">
                        <div class="position-relative" data-aos="fade-left" data-aos-delay="150">
                            <div class="row g-3 align-items-center">
                                <div class="col-5">
                                    <img
                                        src="https://images.pexels.com/photos/5928039/pexels-photo-5928039.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                                        class="img-fluid mb-3 shadow-lg rounded-bottom-end-0 position-relative rounded-4"
                                        alt="">
                                    <img
                                        src="https://images.pexels.com/photos/7581577/pexels-photo-7581577.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                                        class="img-fluid shadow-lg position-relative rounded-top-end-0 rounded-4"
                                        alt="">

                                </div>
                                <div class="col-7">
                                    <img
                                        src="https://images.pexels.com/photos/3764013/pexels-photo-3764013.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                                        class="img-fluid shadow-lg mb-3 rounded-bottom-start-0 position-relative rounded-4"
                                        alt="">
                                    <img
                                        src="https://images.pexels.com/photos/3373721/pexels-photo-3373721.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                                        class="img-fluid shadow-lg position-relative rounded-top-start-0 rounded-4"
                                        alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        @isset($cData->place[8])
            <section class="position-relative bg-tint-primary overflow-hidden">
                <!--Divider shape-->
                <svg class="position-absolute start-0 top-0 text-white" width="100%" height="48"
                     preserveAspectRatio="none" viewBox="0 0 1284 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                          d="M0 0L31.03 14.5833C60.99 29.1667 121.98 58.3333 182.97 62.5C245.03 66.6667 306.02 45.8333 367.01 35.4167C428 25 488.99 25 549.98 37.5C610.97 50 673.03 75 734.02 70.8333C795.01 66.6667 856 33.3333 916.99 31.25C977.98 29.1667 1038.97 58.3333 1101.03 75C1162.02 91.6667 1223.01 95.8333 1252.97 97.9167L1284 100V0H1252.97C1223.01 0 1162.02 0 1101.03 0C1038.97 0 977.98 0 916.99 0C856 0 795.01 0 734.02 0C673.03 0 610.97 0 549.98 0C488.99 0 428 0 367.01 0C306.02 0 245.03 0 182.97 0C121.98 0 60.99 0 31.03 0H0Z"
                          fill="currentColor"></path>
                </svg>
                <div class="container py-9 py-lg-11 position-relative">
                    <div class="row pt-7">
                        <!--Testimonial column-->
                        <div class="col-11 mx-auto col-lg-9" data-aos="fade-right">

                            <!--Testimonial card-->
                            <div class="position-relative">
                                <div class="mb-5 mb-lg-7">
                                    <img src="assets/img/partners/amazon.svg" class="width-8x h-auto" alt="">
                                </div>
                                @isset($cData->place[8][0]->shortdescription)
                                    <h2 class="display-5 font-serif mb-6">
                                        {{$cData->place[8][0]->shortdescription}}
                                    </h2>
                                @endisset
                                @isset($cData->place[8][0]->title)
                                    <h6 class="mb-0">{{$cData->place[8][0]->title}}</h6>
                                @endisset
                                @isset($cData->place[8][0]->buttontext)
                                    <small class="text-muted">{{$cData->place[8][0]->buttontext}}</small>
                                @endisset
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        @endisset
    </main>
@endsection
