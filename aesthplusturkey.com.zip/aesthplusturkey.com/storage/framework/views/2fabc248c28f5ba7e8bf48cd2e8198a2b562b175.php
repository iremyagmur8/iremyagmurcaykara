<?php $__env->startSection('title', $cData->posts->title." - "); ?>
<?php $__env->startSection('desc',$cData->posts->shortdescription); ?>
<?php $__env->startSection('content'); ?>

    <?php
        use App\Http\Controllers\HomepageController
    ?>

    <?php if(isset($cData->category->files[0]->file)): ?>
        <section id="page-title"
                 data-bg-parallax="<?php echo e(Storage::url("/images/userfiles/".$cData->category->files[0]->file)); ?>">
            <div class="bg-overlay"></div>
            <div class="container">
                <div class="page-title">
                    <h1><?php echo e($cData->category->title); ?></h1>
                    <span><?php echo e($cData->category->shortdescription); ?></span>
                </div>
            </div>
        </section>
    <?php endif; ?>
    <section id="page-content" class="background-grey" style="padding: 10px 0;">
        <div class="container">
            <div class="row">

                <div class="content col-md-8">

                    <div id="blog" class="single-post">
                        <div class="post-item">
                            <div class="post-item-wrap">
                                <?php if(isset($cData->posts->files[0]->file)): ?>
                                    <div class="post-image">
                                        <a href="#">
                                            <img width="845" height="475" alt="<?php echo $cData->posts->title; ?>"
                                                 src="<?php echo e(Storage::url("images/userfiles/".$cData->posts->files[0]->file)); ?>">
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <div class="post-item-description" style="padding: 15px">
                                    <?php if(isset($cData->posts->brandtext->files[0]->file)): ?>
                                    <div
                                         style="background:url('<?php echo e(HomepageController::webps($cData->posts->brandtext->files[0]->file,"m")); ?>') center center; background-size:cover; height: 80px; width: 80px; display: inline-block; margin-right: 20px; float:left"></div>
                                    <?php endif; ?>
                                    <h2 style="height: auto;"><?php echo e($cData->posts->title); ?></h2>
                                    <p style="margin-top: 20px"><b><?php echo e($cData->posts->shortdescription); ?></b></p>
                                    <div class="post-meta">
                                        <span class="post-meta-date"><i class="fa fa-calendar-o"></i><?php echo e($cData->posts->created_at); ?></span>
                                        <span class="post-meta-comments"><a href=""><i class="fa fa-comments-o"></i><?php echo e($cData->posts->hit); ?> Hit</a></span>
                                        <span class="post-meta-category"><a href=""><i class="fa fa-tag"></i><?php echo e($cData->posts->category->title); ?></a></span>
                                        <div class="post-meta-share">
                                            <a class="btn btn-xs btn-slide btn-facebook" href="#">
                                                <i class="fab fa-facebook-f"></i>
                                                <span>Facebook</span>
                                            </a>
                                            <a class="btn btn-xs btn-slide btn-twitter" href="#" data-width="100">
                                                <i class="fab fa-twitter"></i>
                                                <span>Twitter</span>
                                            </a>
                                            <a class="btn btn-xs btn-slide btn-instagram" href="#" data-width="118">
                                                <i class="fab fa-instagram"></i>
                                                <span>Instagram</span>
                                            </a>
                                            <a class="btn btn-xs btn-slide btn-googleplus" href="mailto:#"
                                               data-width="80">
                                                <i class="icon-mail"></i>
                                                <span>Mail</span>
                                            </a>
                                        </div>
                                    </div>
                                        <?php echo str_replace('width="560"','width="100%"',$cData->posts->description); ?>


                                    <?php if(count($cData->posts->tags)>1): ?>
                                        <div class="post-tags">
                                            <?php $__currentLoopData = $cData->posts->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="#"><?php echo e($val); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="post-navigation">
                                    <?php if(isset($cData->preview->title)): ?>
                                        <a href="/<?php echo e(str_slug($cData->preview->title,"-")); ?>/<?php echo e($cData->preview->id); ?>.html"
                                           class="post-prev">
                                            <div class="post-prev-title">
                                                <span>Vorherige Nachrichten</span><?php echo e($cData->preview->title); ?>

                                            </div>
                                        </a>
                                    <?php endif; ?>
                                    <a href="/marken/<?php echo e($cData->posts->brandtext); ?>" class="post-all">
                                        <i class="icon-grid"> </i>
                                    </a>
                                    <?php if(isset($cData->next->title)): ?>
                                        <a href="/<?php echo e(str_slug($cData->next->title,"-")); ?>/<?php echo e($cData->next->id); ?>.html"
                                           class="post-next">
                                            <div class="post-next-title"><span>Nächste Nachrichten</span><?php echo e($cData->next->title); ?>

                                            </div>
                                        </a>
                                    <?php endif; ?>
                                </div>



                            </div>
                        </div>


                    </div>
                    <div class="row" style="margin-top: 20px">
                        <?php $__currentLoopData = $cData->brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6" style="padding-right: 15px; padding-left: 15px">
                                <div class="post-item border">
                                    <div class="post-item-wrap">
                                        <div class="post-image">
                                            <a href="/<?php echo e(str_slug($val->title,"-")); ?>/<?php echo e($val->id); ?>.html">
                                                <div class="mansetright"
                                                     style="background:url('<?php echo e(HomepageController::webps($val->files[0]->file,"m")); ?>') center center; background-size:cover; height: 200px"></div>
                                            </a>
                                            <?php if(isset($val->category->title)): ?><span class="post-meta-category"><a
                                                    href=""><?php echo e($val->category->title); ?></a></span><?php endif; ?>
                                        </div>
                                        <div class="post-item-description">
                                            <h3 class="elip3"><a href="/<?php echo e(str_slug($val->title,"-")); ?>/<?php echo e($val->id); ?>.html"><?php echo e($val->title); ?></a></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
                <?php echo $__env->make("home.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/karip/public_html/laravel-neuesmodelauto/resources/views/home/post.blade.php ENDPATH**/ ?>