<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('desc',''); ?>
<?php $__env->startSection('content'); ?>



    <section id="page-content" class="background-grey">
        <div class="container container-fullscreen">
            <div class="text-middle">

                <div class="row">
                    <div class="col-lg-6 center p-50 background-white b-r-6" style="padding-top: 20px !important;">


                        <form class="form-transparent-grey" method="POST" action="<?php echo e(route('register')); ?>">
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger text-center">
                                    <?php echo implode('', $errors->all('<div>:message</div>')); ?>

                                </div>
                            <?php endif; ?>
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="type" value="1"/>
                            <div class="row">
                                <div class="col-lg-12">
                                    <h4>Yeni Hesap Aç</h4>

                                </div>

                                <div class="col-lg-12 form-group">
                                    <label class="sr-only">Adınız Soyadınız</label>
                                    <input type="text" value="" name="name" placeholder="Adınız Soyadınız"
                                           class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                </div>

                                <div class="col-lg-12 form-group">
                                    <label class="sr-only">Email</label>
                                    <input type="text" value="" name="email" placeholder="Email"
                                           class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                </div>

                                <div class="col-lg-12 form-group">
                                    <label class="sr-only">Şifre</label>
                                    <input id="password" type="password" placeholder="Şifre"
                                           class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                           required autocomplete="new-password">
                                </div>

                                <div class="col-lg-12 form-group">
                                    <label class="sr-only">Şifre Tekrar</label>
                                    <input id="password-confirm" type="password" class="form-control"
                                           placeholder="Şifre Tekrar" name="password_confirmation" required
                                           autocomplete="new-password">
                                </div>

                                <div class="col-lg-12 form-group">
                                    <button class="btn" type="submit">Kayıt Ol</button>

                                </div>

                            </div>
                        </form>
                        <p class="small">Zaten üye misiniz? <a href="/login">Giriş Yap</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/healthplusturkey/public_html/resources/views/auth/register.blade.php ENDPATH**/ ?>