<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('desc',''); ?>
<?php $__env->startSection('content'); ?>

    <?php
        use App\Http\Controllers\HomepageController
    ?>


    <section id="page-content" class="background-grey" style="padding: 10px 0;">
        <div class="container">
            <div class="row">

                <div class="content col-md-8">
                    <div class="row">
                        <?php $__currentLoopData = $cData->category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <div class="post-item border">
                                    <div class="post-item-wrap" style="padding: 10px">
                                        <div class="post-image">
                                            <a href="/auto/<?php echo e(str_slug($val->title,"-")); ?>/<?php echo e($val->id); ?>">
                                                <img src="<?php echo e(HomepageController::webps($val->files[0]->file,"l")); ?>">

                                            </a>

                                        </div>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php echo $__env->make("home.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/karip/public_html/laravel-neuesmodelauto/resources/views/home/marken.blade.php ENDPATH**/ ?>