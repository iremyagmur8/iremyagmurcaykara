<?php $__env->startSection('title',' - İletişim'); ?>
<?php $__env->startSection('modulecontent'); ?>


    <div class="portlet-box">
        <div class="portlet-header flex-row flex d-flex align-items-center">
            <a href="/solaris/add/contact" class="btn btn-rounded btn-primary btn-sm m-r-5">Formu
                Sıfırla</a>
            <a href="/solaris/<?php echo e(request("module")); ?>" class="btn btn-rounded btn-danger btn-sm">Tüm İçerikler</a>
        </div>

        <form class="form-horizontal dropzone" method="POST" action="/solaris/addcontact" id="formData"
              enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php if(!empty($cData->data)): ?> <input type="hidden" name="degisID" value="<?php echo e($cData->data->id); ?>"> <?php endif; ?>


            <div class="col-md-12">


                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="title">Adı</label>
                            <input type="text" class="form-control" name="title"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->title); ?><?php endif; ?>"
                                   autofocus>
                        </div>

                        <div class="form-group col-md-6">
                            <label for="title">Slogan</label>
                            <input type="text" class="form-control" name="slogan"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->slogan); ?><?php endif; ?>"
                                   autofocus>
                        </div>


                    </div>

                    <div class="form-row">

                        <div class="form-group col-md-4">
                            <label for="title">Ülke</label>
                            <input type="text" class="form-control" name="country"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->country); ?><?php endif; ?>"
                                   autofocus>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="title">İl</label>
                            <input type="text" class="form-control" name="city"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->city); ?><?php endif; ?>"
                                   autofocus>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="title">İlçe</label>
                            <input type="text" class="form-control" name="district"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->district); ?><?php endif; ?>"
                                   autofocus>
                        </div>

                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label for="title">Adres</label>
                            <textarea class="form-control" name="address"  autofocus><?php if(!empty($cData->data)): ?><?php echo e($cData->data->address); ?><?php endif; ?></textarea>
                        </div>

                    </div>

                    <div class="form-row">


                        <div class="form-group col-md-4">
                            <label for="title">Telefon</label>
                            <input type="text" class="form-control" name="phone"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->phone); ?><?php endif; ?>"
                                   autofocus>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="title">Fax</label>
                            <input type="text" class="form-control" name="fax"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->fax); ?><?php endif; ?>"
                                   autofocus>
                        </div>

                    </div>

                    <div class="form-row">

                        <div class="form-group col-md-4">
                            <label for="title">Mail</label>
                            <input type="text" class="form-control" name="mail"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->mail); ?><?php endif; ?>"
                                   autofocus>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="title">Mail 2</label>
                            <input type="text" class="form-control" name="mail2"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->mail2); ?><?php endif; ?>"
                                   autofocus>
                        </div>

                    </div>

                    <div class="form-row">


                        <div class="form-group col-md-12">
                            <label for="title">GoogleMap Kordinat</label>
                            <input type="text" class="form-control" name="googlemap"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->googlemap); ?><?php endif; ?>"
                                   autofocus>
                        </div>

                    </div>

                    <div class="form-row">


                        <div class="form-group col-md-4">
                            <label for="title">Facebook</label>
                            <input type="text" class="form-control" name="facebook"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->facebook); ?><?php endif; ?>"
                                   autofocus>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="title">Twitter</label>
                            <input type="text" class="form-control" name="twitter"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->twitter); ?><?php endif; ?>"
                                   autofocus>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="title">Instagram</label>
                            <input type="text" class="form-control" name="instagram"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->instagram); ?><?php endif; ?>"
                                   autofocus>
                        </div>

                    </div>

                    <div class="form-row">


                        <div class="form-group col-md-4">
                            <label for="title">Linked In</label>
                            <input type="text" class="form-control" name="linkedin"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->linkedin); ?><?php endif; ?>"
                                   autofocus>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="title">Youtube</label>
                            <input type="text" class="form-control" name="youtube"
                                   value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->youtube); ?><?php endif; ?>"
                                   autofocus>
                        </div>

                        <div class="form-group col-md-12">
                        <textarea class="form-control" id="summary-ckeditor"
                                  name="description"><?php if(!empty($cData->data)): ?><?php echo e($cData->data->description); ?><?php endif; ?></textarea>
                        </div>


                        <div class="form-group col-md-12">
                            <label for="document">Dosyalar</label>
                            <input type="file"
                                   class="filepond"
                                   name="file[]"
                                   multiple
                                   data-allow-reorder="true">
                        </div>

                        <div class="form-group">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-primary">
                                    Kaydet
                                </button>
                            </div>
                        </div>


                    </div>





            </div>
        </form>

        </div>






    <script src="//cdn.ckeditor.com/4.14.0/full/ckeditor.js"></script>
    <script>

        CKEDITOR.replace('summary-ckeditor', {
            filebrowserUploadUrl: "<?php echo e(route('ckupload', ['_token' => csrf_token() ])); ?>",
            filebrowserUploadMethod: 'form',
            height: 500
        });

        FilePond.registerPlugin(
            FilePondPluginImageCrop,
            FilePondPluginImagePreview,
            FilePondPluginFilePoster
        );

        // Get a reference to the file input element
        const inputElement = document.querySelector('.filepond');

        // Create the FilePond instance
        const pond = FilePond.create(inputElement, {
            allowImageEdit: true,
            labelIdle: 'Sürükle ya da <span class="filepond--label-action"> seç </span>',
            styleImageEditButtonEditItemPosition: 'bottom',
            imageCropAspectRatio: '1:1',
            onreorderfiles: (files, origin, target) => {
                var images = []
                files.forEach(element => {
                    images.push(element.file.name)
                });
                $.ajax({
                    method: "POST",
                    url: "/solaris/sortfiles",
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    data: {file: images}
                })
                    .done(function (msg) {
                        console.log(msg);
                    });

            },
            server: {
                url: '/filepond/api',
                process: '/process',

                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                load: (source, load, error, progress, abort, headers) => {
                    var request = new Request(source);
                    fetch(request).then(function (response) {
                        response.blob().then(function (myBlob) {
                            load(myBlob)
                        });
                    });

                },

                remove: (source, load, error, options) => {
                    console.log(source);
                    console.log(options);

                    $.ajax({
                        method: "POST",
                        url: "/solaris/deletefile",
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        data: {file: source}
                    })
                        .done(function (msg) {
                            console.log(msg);
                        });
                    load();


                },

            }
            <?php if(isset($cData->data)): ?>
            , files: [
                    <?php $__currentLoopData = $cData->data->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    source: '<?php echo e(config('solaris.site.url').Storage::url("images/userfiles/".$val->file)); ?>',
                    options: {
                        type: 'local',

                    },
                    metadata: {
                        poster: '<?php echo e(config('solaris.site.url').Storage::url("images/userfiles/".$val->file)); ?>'
                    }
                }
                <?php if(!$loop->last): ?> , <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],

            <?php endif; ?>

        });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('solaris.module', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/healthplusturkey/public_html/aesthplusturkey.com/resources/views/solaris/create-contact.blade.php ENDPATH**/ ?>