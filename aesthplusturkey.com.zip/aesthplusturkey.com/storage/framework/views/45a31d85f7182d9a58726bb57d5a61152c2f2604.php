<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('desc',''); ?>
<?php $__env->startSection('content'); ?>
    <?php
        use App\Http\Controllers\HomepageController
    ?>
    <section class="content background-grey">
        <div class="container">



        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/karip/public_html/laravel-default/resources/views/home/index.blade.php ENDPATH**/ ?>