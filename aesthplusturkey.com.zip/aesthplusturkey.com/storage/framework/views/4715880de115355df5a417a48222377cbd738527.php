<?php echo '<'.'?xml'; ?> version="1.0" encoding="UTF-8"?>
<methodCall>
    <methodName>weblogUpdates.ping</methodName>
    <params>
        <param>
            <value><?php echo e($title); ?></value>
        </param>
        <param>
            <value><?php echo e($url); ?></value>
        </param>
        <?php if(!empty($rss)): ?>
            <param>
                <value><?php echo e($rss); ?></value>
            </param>
        <?php endif; ?>
    </params>
</methodCall><?php /**PATH /home/healthplusturkey/public_html/aesthplusturkey.com/vendor/garf/laravel-pinger/src/views/xml.blade.php ENDPATH**/ ?>