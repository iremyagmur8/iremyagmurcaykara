<?php
    use App\Http\Controllers\HomepageController
?>

<div class="col-md-4">
    <div class="widget clearfix widget-archive">
        <div class="post-item border">
            <div class="post-item-wrap" style="padding: 10px">
                <h4 class="widget-title">Top Hits</h4>

                <div class="post-thumbnail-list">
                    <?php $__currentLoopData = $vars->hits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post-thumbnail-entry">
                            <div
                                style="background:url('<?php echo e(HomepageController::webps($val->files[0]->file,"s")); ?>') center center; background-size:cover; height: 70px; width: 80px; display: inline-block; float:left;  margin-right:10px"></div>
                            <div class="post-thumbnail-content">
                                <a href="/<?php echo e(str_slug($val->title,"-")); ?>/<?php echo e($val->id); ?>.html"><?php echo e($val->title); ?></a>
                                <span class="post-date"><i class="icon-clock"></i> <?php echo e($val->date); ?></span>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <hr>

                <h4 class="widget-title">Letzte Nachrichten</h4>

                <div class="post-thumbnail-list">
                    <?php $__currentLoopData = $vars->recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="post-thumbnail-entry">
                            <div
                                style="background:url('<?php echo e(HomepageController::webps($val->files[0]->file,"s")); ?>') center center; background-size:cover; height: 70px; width: 80px; display: inline-block; float:left;  margin-right:10px"></div>
                            <div class="post-thumbnail-content">
                                <a href="/<?php echo e(str_slug($val->title,"-")); ?>/<?php echo e($val->id); ?>.html"><?php echo e($val->title); ?></a>
                                <span class="post-date"><i class="icon-clock"></i> <?php echo e($val->date); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <br style="clear: both">
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/karip/public_html/laravel-neuesmodelauto/resources/views/home/sidebar.blade.php ENDPATH**/ ?>