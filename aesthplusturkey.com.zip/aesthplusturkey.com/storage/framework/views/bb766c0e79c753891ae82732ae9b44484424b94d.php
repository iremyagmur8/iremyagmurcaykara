<?php echo '<?xml version="1.0" encoding="UTF-8"?>';
    use App\Http\Controllers\HomepageController
?>
<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd http://www.google.com/schemas/sitemap-image/1.1 http://www.google.com/schemas/sitemap-image/1.1/sitemap-image.xsd"
        xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <?php $__currentLoopData = $cData->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <url>
            <loc><?php echo e(config()->get("solaris.site.url")); ?><?php echo e(str_slug($val->title,"-")); ?>/<?php echo e($val->id); ?>.html</loc>
            <lastmod><?php echo e(date("Y-m-d\TH:i:s+00:00",strtotime($val->updated_at))); ?></lastmod>
            <?php if(isset($val->files[0]->file)): ?>
                <image:image>
                    <image:loc><?php echo e(config()->get("solaris.site.url")); ?><?php echo e(substr(HomepageController::webps($val->files[0]->file,"l"),1)); ?></image:loc>
                    <image:title><![CDATA[<?php echo $val->title; ?>]]></image:title>
                </image:image>
            <?php endif; ?>

        </url>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</urlset>
<?php /**PATH /home/healthplusturkey/public_html/resources/views/home/sitemap.blade.php ENDPATH**/ ?>