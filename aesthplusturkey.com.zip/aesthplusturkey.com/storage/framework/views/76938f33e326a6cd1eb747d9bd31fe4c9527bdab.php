<?php $__env->startSection('title', 'Kategoriler'); ?>
<?php $__env->startSection('modulecontent'); ?>
    <?php
        $module="categories";
    ?>
    <?php if(session('status')): ?>
        <?php $type = session('type');?>
    <?php endif; ?>
    <?php if(session('status')): ?>
        <div class="alert alert-<?php echo e(session('status')); ?> " id="notification">
            <?php echo e(session('msg')); ?>

        </div>
        <script>
            setTimeout(function () {
                $("#notification").slideUp();
            }, 2000);
        </script>
    <?php endif; ?>

    <div class="portlet-box">
        <div class="portlet-header flex-row flex d-flex align-items-center">
            <a href="/solaris/categories" class="btn btn-rounded btn-primary btn-sm m-r-5">Formu Sıfırla</a>
        </div>


        <div class="row" style="padding: 20px">
            <div class="col-md-7">


                <form class="form-horizontal dropzone" method="POST" action="/solaris/categories" id="formData" enctype="multipart/form-data">
                    <div class="row">
                        <?php echo e(csrf_field()); ?>


                        <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                <strong><?php echo e($message); ?></strong>
                            </div>
                        <?php endif; ?>

                        <?php if(isset($cData->data)): ?>
                            <input type="hidden" name="degisID" value="<?php echo e($cData->data->id); ?>">
                            <?php
                                $type=$cData->data->type;
                            ?>

                        <?php else: ?>
                            <?php
                                $type=0;
                            ?>
                        <?php endif; ?>


                        <div class="form-group col-md-12">
                            <label for="title" style="float:left; margin-right:10px">Kategori Adı </label>
                            <div class="customUi-checkbox checkbox-rounded checkboxUi-primary  pb-2" style="float:left;;">
                                <input id="sqr" type="checkbox" name="active" value="1">
                                <label for="sqr">
                                    <span class="label-checkbox"></span>
                                    <small class="label-helper">Aktif</small>
                                </label>
                            </div>
                            <input type="text" class="form-control" name="title"
                                   value="<?php if(isset($cData->data)): ?><?php echo e($cData->data->title); ?><?php endif; ?>"
                                   autofocus>
                        </div>


                        <div class="form-group col-md-3">
                            <label for="type">Kategori Tipi</label>
                            <select class="form-control" name="type"
                                    onchange="$('#taba-'+this.value).tab('show');" id="categoryChanger">

                                <?php $__currentLoopData = Config::get('solaris.catTypes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($val["id"]); ?>"
                                            <?php if(!empty($cData->data) && $cData->data->type == $val["id"]): ?> selected
                                            <?php endif; ?> <?php if(isset($type)): ?> <?php if($type == $val["id"]): ?> selected <?php endif; ?> <?php endif; ?>>
                                        <?php echo e($val["name"]); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select>
                        </div>
                        <div class="form-group col-md-2">
                            <label for="title">Sıra</label>
                            <input type="text" class="form-control" name="sort"
                                   value="<?php if(isset($cData->data)): ?><?php echo e($cData->data->sort); ?><?php endif; ?><?php echo e(old('sort')); ?>">
                        </div>

                        <div class="form-group col-md-3">
                            <label for="title">Temalar</label>
                            <select class="form-control" name="theme"
                                    onchange="$('#taba-'+this.value).tab('show')">

                                <?php $__currentLoopData = Config::get('solaris.catThemes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($val); ?>"
                                            <?php if(!empty($cData->data) && $cData->data->theme == $val): ?> selected
                                        <?php endif; ?>>
                                        <?php echo e($val); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select>
                        </div>

                        <div class="form-group col-md-4">
                            <label for="type">Üst Kategorisi</label>
                            <select class="form-control" name="parent_id" id="ustKategori">
                                <option value="0"
                                        <?php if(!empty($cData->data) && $cData->data->id == 0): ?> selected <?php endif; ?>>
                                    Lütfen Seçin
                                </option>

                                <?php if(isset($allCategories[$type] )): ?>
                                    <?php $__currentLoopData = $allCategories[$type]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"
                                                <?php if(!empty($cData->data) && $cData->data->parent_id == $category->id): ?> selected <?php endif; ?>><?php echo e($category->title); ?></option>

                                        <?php if(count($category->childs)): ?>
                                            <?php $padding = " "; ?>

                                            <?php if(!empty($cData)): ?> <?php echo $__env->make('solaris.categories.subCategories',['childs' => $category->childs,'padding'=> $padding,'cData'=>$cData], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php else: ?> <?php echo $__env->make('solaris.categories.subCategories',['childs' => $category->childs,'padding'=> $padding], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endif; ?>

                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>


                            </select>
                        </div>

                        <div class="form-group col-md-12 ">
                            <label for="title">Kısa Açıklama</label>
                            <textarea class="form-control" id="" style="height: 50px"
                                      name="shortdescription"><?php if(isset($cData->data)): ?><?php echo e($cData->data->shortdescription); ?><?php endif; ?></textarea>
                            <a style="font-size: 12px; float: right; color:#0084ff" onclick="$('.kategoriDevam').slideToggle();">Gelişmiş</a>
                        </div>


                        <div class="gizli kategoriDevam row" style="<?php if(empty($cData->data)): ?> display: none <?php endif; ?> ; padding: 20px">
                            <div class="form-group col-md-6">
                                <label for="title">Link</label>
                                <input type="text" class="form-control" name="link"
                                       placeholder="Link"
                                       value="<?php if(isset($cData->data)): ?><?php echo e($cData->data->link); ?><?php endif; ?><?php echo e(old('order')); ?>">
                            </div>

                            <div class="form-group col-md-6">
                                <label for="type">Open Link </label>
                                <select class="form-control" name="openlink"
                                        onchange="$('#taba-'+this.value).tab('show')">

                                    <?php $__currentLoopData = Config::get('solaris.catTypes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($val["id"]); ?>"
                                                <?php if(!empty($cData->data) && $cData->data->type == $val["id"]): ?> selected
                                                <?php endif; ?> <?php if(isset($type)): ?> <?php if($type == $val["id"]): ?> selected <?php endif; ?> <?php endif; ?>>
                                            <?php echo e($val["name"]); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                </select>
                            </div>


                            <div class="form-group col-md-12">
                                <label for="title"> Açıklama</label>
                                <textarea class="form-control" id="summary-ckeditor" name="description"><?php if(isset($cData->data)): ?><?php echo e($cData->data->description); ?><?php endif; ?><?php echo e(old('description')); ?></textarea>
                                <script src="//cdn.ckeditor.com/4.14.0/full/ckeditor.js"></script>
                            </div>

                            <div class="form-group col-md-12">
                                <label for="document">Dosyalar</label>
                                <input type="file"
                                       class="filepond"
                                       name="file[]"
                                       multiple
                                       data-allow-reorder="true">
                            </div>
                        </div>

                        <div class="form-group" style="padding:20px">
                            <button class="btn btn-success">Kaydet</button>
                        </div>

                    </div>
                </form>

            </div>
            <div class="col-md-5" style="border-left: 1px solid #eee">


                <div class="tabs tabs-folder ">
                    <ul class="nav nav-tabs" id="kategoriTabs" role="tablist">
                        <?php $__currentLoopData = Config::get('solaris.catTypes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link  <?php if(isset($type) and $val["id"]==$type): ?> active <?php elseif(!isset($type) and $loop->first): ?> active <?php endif; ?> "
                                   id="taba-<?php echo e($val["id"]); ?>" data-toggle="tab" href="#<?php echo e(str_slug($val["name"],"-")); ?>" role="tab"
                                   aria-controls="<?php echo e(str_slug($val["name"],"-")); ?>" aria-selected="true"><?php echo e($val["name"]); ?></a>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>


                    <div class="tab-content" id="myTabContent3">
                        <?php $__currentLoopData = Config::get('solaris.catTypes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="tab-pane    <?php if(isset($type) and $val["id"]==$type): ?> active <?php elseif(!isset($type) and $loop->first): ?> active <?php endif; ?>  "
                                 id="<?php echo e(str_slug($val["name"],"-")); ?>" role="tabpanel"
                                 aria-labelledby="<?php echo e(str_slug($val["name"],"-")); ?>-tab">
                                <table class="table table-striped">
                                    <tr>
                                        <th>Adı</th>
                                        <th>Sıra</th>
                                        <th>ID</th>
                                        <th></th>
                                    </tr>
                                    <?php
                                        $padding = 0;
                                    ?>
                                    <?php if(isset($allCategories[$val["id"]])): ?>
                                        <?php $__currentLoopData = $allCategories[$val["id"]]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr id="dat-<?php echo e($category->id); ?>">
                                                <td><?php echo e($category->title); ?></td>
                                                <td><?php echo e($category->sort); ?></td>
                                                <td><?php echo e($category->id); ?></td>

                                                <td>

                                                    <a href="/solaris/categories/edit/<?php echo e($category->id); ?>"
                                                       class="btn btn-primary btn-sm"><i
                                                            class="fas fa-edit"></i></a>

                                                    <a style="float: right;"
                                                       onclick="sil('<?php echo e(Crypt::encryptString(json_encode(array("sID"=>$category->id,"func"=>"category","method"=>"destroy")))); ?>',<?php echo e($category->id); ?>)"
                                                       class="btn btn-danger btn-sm"><i
                                                            class="fas fa-times"></i></a>

                                                </td>
                                            </tr>
                                            <?php if(count($category->childs)): ?>

                                                <?php echo $__env->make('solaris.categories.manageChild',['childs' => $category->childs,'padding'=> $padding], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                            <?php endif; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </table>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

            </div>


        </div>


    </div>


    <script>

        CKEDITOR.replace('summary-ckeditor', {
            filebrowserUploadUrl: "<?php echo e(route('ckupload', ['_token' => csrf_token() ])); ?>",
            filebrowserUploadMethod: 'form',
            height: 500
        });

        FilePond.registerPlugin(
            FilePondPluginImageCrop,
            FilePondPluginImagePreview,
            FilePondPluginFilePoster
        );

        // Get a reference to the file input element
        const inputElement = document.querySelector('.filepond');

        // Create the FilePond instance
        const pond = FilePond.create(inputElement, {
            allowImageEdit: true,
            labelIdle: 'Sürükle ya da <span class="filepond--label-action"> seç </span>',
            styleImageEditButtonEditItemPosition: 'bottom',
            imageCropAspectRatio: '1:1',
            server: {
                url: '/filepond/api',
                process: '/process',

                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                load: (source, load, error, progress, abort, headers) => {
                    var request = new Request(source);
                    fetch(request).then(function (response) {
                        response.blob().then(function (myBlob) {
                            load(myBlob)
                        });
                    });

                },

                remove: (source, load, error, options) => {
                    console.log(source);
                    console.log(options);

                    $.ajax({
                        method: "POST",
                        url: "/solaris/deletefile",
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        data: {file: source}
                    })
                        .done(function (msg) {
                            console.log(msg);
                        });
                    load();


                },

            }
            <?php if(isset($cData->data)): ?>
            , files: [
                    <?php $__currentLoopData = $cData->data->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    source: '<?php echo e(config('solaris.site.url').Storage::url("images/userfiles/".$val->file)); ?>',
                    options: {
                        type: 'local',

                    },
                    metadata: {
                        poster: '<?php echo e(config('solaris.site.url').Storage::url("images/userfiles/".$val->file)); ?>'
                    }
                }
                <?php if(!$loop->last): ?> , <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],

            <?php endif; ?>

        });

        $("#categoryChanger").change(function () {


            $.ajax({
                method: "POST",
                url: "/solaris/subCats",
                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                data: {type: this.value}
            })
                .done(function (msg) {
                    $("#ustKategori").html(msg);

                });


        });


    </script>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('solaris.module', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/healthplusturkey/public_html/resources/views/solaris/categories/categoryTreeview.blade.php ENDPATH**/ ?>