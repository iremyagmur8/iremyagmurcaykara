<?php
    $padding = $padding + 40;
?>
<?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr  id="dat-<?php echo e($child->id); ?>">
        <td style="padding-left: <?php echo e($padding); ?>px">
            <?php echo e($child->title); ?></td>
        <td><?php echo e($child->order); ?></td>
        <td><?php echo e($child->id); ?></td>
        <td nowrap="nowrap">
            <a  href="/solaris/categories/edit/<?php echo e($child->id); ?>"  class="btn btn-primary btn-sm ikonButton"><i class="fas fa-edit"></i></a>

            <a style="margin-left: 10px" onclick="sil('<?php echo e(Crypt::encryptString(json_encode(array("sID"=>$child->id,"func"=>"category","method"=>"destroy")))); ?>',<?php echo e($child->id); ?>)" class="btn btn-danger btn-sm ikonButton"><i class="fas fa-times"></i></a>
        </td>
    </tr>
    <?php if(count($child->childs)): ?>

        <?php if(!empty($cData)): ?> <?php echo $__env->make('solaris.categories.manageChild',['childs' => $child->childs,'cData'=>$cData], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?> <?php echo $__env->make('solaris.categories.manageChild',['childs' => $child->childs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>



    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH /home/healthplusturkey/public_html/resources/views/solaris/categories/manageChild.blade.php ENDPATH**/ ?>