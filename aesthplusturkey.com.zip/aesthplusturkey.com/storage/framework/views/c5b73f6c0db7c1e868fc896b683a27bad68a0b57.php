<?php
    use App\Http\Controllers\HomepageController
?>
<div class="post-item border">
    <div class="post-item-wrap">
        <div class="post-image">
            <a href="/<?php echo e(str_slug($bVal->title,"-")); ?>/<?php echo e($bVal->id); ?>.html">
                <?php if(isset($bVal->files[0]->file)): ?><div class="mansetright lazys "  data-src="<?php echo e(HomepageController::webps($bVal->files[0]->file,"l")); ?>"  style="background:url('<?php echo e(HomepageController::webps($bVal->files[0]->file,"l")); ?>') center center; background-size:cover; height: <?php echo e($height); ?>px"></div><?php endif; ?>
            </a>
            <?php if(isset($bVal->category->title)): ?>
                <span class="badge badge-danger "><a href="/<?php echo e($bVal->category->link); ?>"><?php echo e($bVal->category->title); ?></a></span>
            <?php endif; ?>
            <?php if(!isset($date)): ?>
                <span class="post-meta-date"><i class="fa fa-calendar-o"></i><?php echo e($bVal->date); ?></span>
            <?php endif; ?>
        </div>
        <div class="post-item-description">
            <?php if(isset($title) and $title==1): ?>
                <h3 class="boxtitle1"><a href="/<?php echo e(str_slug($bVal->title,"-")); ?>/<?php echo e($bVal->id); ?>.html"><?php echo e($bVal->title); ?></a></h3>
            <?php elseif(isset($title) and $title==2): ?>
                <h3 class="boxtitle2"><a href="/<?php echo e(str_slug($bVal->title,"-")); ?>/<?php echo e($bVal->id); ?>.html"><?php echo e($bVal->title); ?></a></h3>
            <?php elseif(isset($title) and $title==3): ?>
                <h3 class="boxtitle3"><a href="/<?php echo e(str_slug($bVal->title,"-")); ?>/<?php echo e($bVal->id); ?>.html"><?php echo e($bVal->title); ?></a></h3>
            <?php else: ?>
                <h2><a href="/<?php echo e(str_slug($bVal->title,"-")); ?>/<?php echo e($bVal->id); ?>.html"><?php echo e($bVal->title); ?></a></h2>
            <?php endif; ?>
            <?php if(!isset($desc)): ?>
                <p style="height: 92px"><?php echo e($bVal->shortdescription); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /home/healthplusturkey/public_html/aesthplusturkey.com/resources/views/inc/postBox.blade.php ENDPATH**/ ?>