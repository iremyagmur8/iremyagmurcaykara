<?php $__env->startSection('title'); ?>
<?php $__env->startSection('desc'); ?>
<?php $__env->startSection('content'); ?>

    <main>
        <?php if(isset($cData->post[0])): ?>
            <section class="position-relative bg-secondary text-white">
                <!--Divider shape bottom-->
                <svg class="position-absolute start-0 bottom-0 text-white" preserveAspectRatio="none" width="100%"
                     height="288" viewBox="0 0 1200 288" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                          d="M0 144L100 150C200 156 400 168 600 144C800 120 1000 60 1100 30L1200 0V288H1100C1000 288 800 288 600 288C400 288 200 288 100 288H0V144Z"
                          fill="currentColor"/>
                </svg>

                <div class="container pt-14 pb-9 position-relative z-index-1">
                    <div class="row pt-lg-5 pb-7 align-items-center">
                        <div class="col-lg-10 mx-auto text-center">
                            <?php if(isset($cData->post[0]->title)): ?>
                                <h1 class="display-2 mb-4">
                                    <?php echo e($cData->post[0]->title); ?>

                                </h1>
                            <?php endif; ?>

                            <?php if(isset($cData->post[0]->shortdescription)): ?>
                                <p class="mb-11 mb-lg-14 lead w-lg-80 mx-auto"><?php echo e($cData->post[0]->shortdescription); ?></p>
                            <?php endif; ?>
                            <a href="#next"
                               class="text-mutedtext-dark width-8x height-8x shadow bg-white rounded-circle flex-center d-flex text-center mx-auto">
                                <div class="link-arrow-bounce">
                                    <i class="bx bx-down-arrow-alt fs-4"></i>
                                </div>
                            </a>
                        </div>
                    </div>
                    <!--/.end-row--->
                </div>
                <!--/.End-content-->
            </section>
        <?php endif; ?>
        <section class="position-relative overflow-hidden" id="next">
            <div class="container py-9 py-lg-11">
                <?php if(isset($cData->post)): ?>
                    <?php $__currentLoopData = $cData->post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$loop->first): ?>
                            <div class="row justify-content-md-around mb-7 mb-lg-11 align-items-center">
                                <div class="col-md-6 mb-5 mb-md-0 <?php if($loop->iteration % 2 == 0): ?> order-md-last <?php endif; ?>"
                                     data-aos="fade-left" data-aos-delay="100">
                                    <img
                                        src="https://images.pexels.com/photos/5938255/pexels-photo-5938255.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
                                        class="img-fluid rounded-blob shadow-lg" alt="">
                                </div>
                                <div class="col-md-4 <?php if($loop->iteration % 2 == 0): ?> order-md-1 <?php endif; ?>"
                                     data-aos="fade-right" <?php if($loop->iteration % 2 == 0): ?> data-aos-delay="100" <?php endif; ?>>
                                    <div class="d-flex align-items-center mb-4">
                                        <?php if(isset($val->title)): ?>
                                            <h1 class="mb-0 display-6">
                                                <?php echo e($val->title); ?>

                                            </h1>
                                        <?php endif; ?>
                                    </div>
                                    <?php if(isset($val->shortdescription)): ?>

                                        <p class="mb-4">
                                            <?php echo e($val->shortdescription); ?>

                                        </p>
                                    <?php endif; ?>
                                    <?php if(isset($val->link)): ?>
                                        <?php
                                            $links = explode("," ,  $val->link);
                                            $f= 0
                                        ?>
                                        <ul class="list-unstyled text-dark">
                                            <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="d-flex align-items-center <?php if($loop->last): ?> <?php else: ?> mb-3 <?php endif; ?>">
                                                    <i class="bx bx-check-circle fs-4 opacity-50 me-2"></i>
                                                    <span><?php echo e($val); ?></span>
                                                    <?php ($f++); ?>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php endif; ?>
                                </div>
                                <!--/.End Col-->
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>

        </section>

        <section class="position-relative bg-secondary text-white overflow-hidden">

            <!--Divider shape top-->
            <svg class="position-absolute start-0 top-0 flip-y text-white" width="100%" height="48"
                 preserveAspectRatio="none" viewBox="0 0 1870 210" xmlns="http://www.w3.org/2000/svg">
                <path fill="currentColor"
                      d="M977.9,76.2 C475.2,-17.4 0.2,132.5 0.2,132.5 L0.2,275.5 L1891.3,275.5 L1891.3,0.7 C1891.3,0.7 1480.6,169.8 977.9,76.2 Z"></path>
            </svg>
            <!--Divider shape bottom-->
            <svg class="position-absolute start-0 bottom-0 text-white" width="100%" height="48"
                 preserveAspectRatio="none" viewBox="0 0 1870 210" xmlns="http://www.w3.org/2000/svg">
                <path fill="currentColor"
                      d="M977.9,76.2 C475.2,-17.4 0.2,132.5 0.2,132.5 L0.2,275.5 L1891.3,275.5 L1891.3,0.7 C1891.3,0.7 1480.6,169.8 977.9,76.2 Z"></path>
            </svg>
            <div class="container position-relative z-index-1 py-12 py-lg-18">
                <h2 class="display-4 mb-5 mb-lg-9">İlginizi Çekebilir...</h2>
                <div class="row pb-4 justify-content-center">
                    <?php if(isset($cData->next )): ?>
                        <?php $__currentLoopData = $cData->next; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 mb-7 <?php if($loop->last): ?> <?php else: ?> mb-lg-0 <?php endif; ?>" data-aos="fade-up">
                                <div class="h-100">
                                    <h5 class="mb-3"><?php echo e($val->title); ?></h5>
                                    <p class="mb-3 flex-grow-1 text-muted" style="    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow:hidden;
">
                                        <?php echo e($val->shortdescription); ?>

                                    </p>
                                    <div class="d-inline-flex align-items-center">
                                        <a href="<?php echo e("/".str_slug($val->title,"-")."/".$val->id.".htm"); ?>"
                                           class="link-underline">Daha Fazlası İçin
                                            <i class="bx bx-chevron-right fs-4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <!--End container-->
        </section>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/healthplusturkey/public_html/aesthplusturkey.com/resources/views/home/post.blade.php ENDPATH**/ ?>