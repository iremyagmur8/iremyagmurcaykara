<?php $__env->startSection('title', $cData->posts->title." - "); ?>
<?php $__env->startSection('desc',$cData->posts->shortdescription); ?>
<?php $__env->startSection('content'); ?>
    <?php use App\Http\Controllers\HomepageController ?>
<main id="content" role="main" class="">
    <article class="recipe-article">
        <header>
            <span class="ampstart-subtitle block pt2 mb2"><?php echo e($cData->posts->category->title); ?></span>
            <h1 class="mb1 ampstart-title-md mb4"><?php echo e($cData->posts->title); ?></h1>

            <!-- Start byline -->
            <address class="ampstart-byline clearfix">
                <time style="font-size: 1em;"
                    class="ampstart-byline-pubdate block bold"
                    datetime="<?php echo e(date("Y-m-d H:i",strtotime($cData->posts->updated_at))); ?>"
                ><?php echo e(date("Y-m-d H:i",strtotime($cData->posts->updated_at))); ?></time
                >
            </address>
            <!-- End byline -->
            <amp-img
                src="<?php echo e(HomepageController::webps($cData->posts->files[0]->file,"m")); ?>"
                width="1280"
                height="853"
                layout="responsive"
                alt="<?php echo e($cData->posts->title); ?>"
                class="mb4"
            ></amp-img>
        </header>
        <?php echo str_replace('width="560"','width="100%"',$cData->posts->description); ?>








        <?php if(count($cData->posts->tags)>1): ?>
            <section>
                <h2 class="mb3">Categories</h2>
                <ul class="list-reset p0 m0 mb4">
                <?php $__currentLoopData = $cData->posts->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mb2">
                            <a href="#" class="text-decoration-none h3"><?php echo e($val); ?></a>
                        </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </section>
            </section>
        <?php endif; ?>




    </article>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-amp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/karip/public_html/laravel-neuesmodelauto/resources/views/home/amp-post.blade.php ENDPATH**/ ?>