<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('desc',''); ?>
<?php $__env->startSection('content'); ?>

    <?php
        use App\Http\Controllers\HomepageController
    ?>


    <section id="page-content" class="background-grey" style="padding: 10px 0;">
        <div class="container">
            <div class="row">

                <div class="content col-md-8">
                    <div class="row">
                        <?php $__currentLoopData = $cData->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6">
                                    <?php echo $__env->make("inc.postBox",['bVal'=>$val,"title"=>1,"height"=>200], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php echo $__env->make("home.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/karip/public_html/laravel-neuesmodelauto/resources/views/home/category.blade.php ENDPATH**/ ?>