<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('desc',''); ?>
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $cData->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make("inc.mobil-postBox",['bVal'=>$val,"title"=>1,"height"=>200], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/karip/public_html/laravel-neuesmodelauto/resources/views/home/mobil-index.blade.php ENDPATH**/ ?>