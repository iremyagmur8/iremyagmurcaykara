<?php $__env->startSection('title', $cData->posts->title." - "); ?>
<?php $__env->startSection('desc',$cData->posts->shortdescription); ?>
<?php $__env->startSection('content'); ?>
    <?php use App\Http\Controllers\HomepageController ?>

    <?php if(isset($cData->posts->files[0]->file)): ?>
        <div class="post-image">
            <a href="#">
                <img width="100%" height="240" alt="<?php echo $cData->posts->title; ?>"
                     src="<?php echo e(HomepageController::webps($cData->posts->files[0]->file,"m")); ?>">
            </a>
        </div>
    <?php endif; ?>

    <div class="container">
        <h2 class="title"><?php echo e($cData->posts->title); ?></h2>
        <p style="margin-top: 20px"><?php echo e($cData->posts->shortdescription); ?></p>
        <div class="post-meta">
            <span><?php echo e($cData->posts->created_at); ?></span><br>
            <span><?php echo e($cData->posts->hit); ?> Hit</span><br>
            <span><?php echo e($cData->posts->category->title); ?></span><br>
        </div>
        <?php echo str_replace('width="560"','width="100%"',$cData->posts->description); ?>

        <?php if(count($cData->posts->tags)>1): ?>
            <div class="post-tags">
                <?php $__currentLoopData = $cData->posts->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#"><?php echo e($val); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php if(count($cData->brands)>0): ?>
            <h3>Verwandte Artikel</h3>
            <?php $__currentLoopData = $cData->brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make("inc.mobil-postBox",['bVal'=>$val,"title"=>1,"height"=>200], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/karip/public_html/laravel-neuesmodelauto/resources/views/home/mobil-post.blade.php ENDPATH**/ ?>