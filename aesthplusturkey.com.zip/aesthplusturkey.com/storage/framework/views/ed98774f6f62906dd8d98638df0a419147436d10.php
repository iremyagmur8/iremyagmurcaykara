<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('desc',''); ?>
<?php $__env->startSection('content'); ?>


    <section id="page-content" class="background-grey">
        <div class="container">

            <div class="row">

                <div class="col-lg-5 center p-50 background-white b-r-6" style="padding-top: 20px !important;">

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger text-center">
                            <?php echo implode('', $errors->all('<div>:message</div>')); ?>

                        </div>
                    <?php endif; ?>
                    <h4>Lütfen Giriş Yapın</h4>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label class="sr-only">Email</label>
                            <input type="text" class="form-control" name="email" placeholder="Email adresinizi yazın">
                        </div>
                        <div class="form-group m-b-5">
                            <label class="sr-only">Şifre</label>
                            <input type="password" class="form-control" name="password"  placeholder="Şifrenizi yazın">
                        </div>
                        <div class="form-group form-inline text-left">
                            <div class="form-check">
                                <label>
                                    <input type="checkbox"><small class="m-l-10"> Beni Hatırla</small>
                                </label>
                            </div>
                        </div>
                        <div class="text-left form-group">
                            <button type="submit" class="btn">Giriş Yap</button>
                        </div>
                    </form>
                    <p class="small">Hesabınız yok mu? <a href="/register">Kayıt Olun</a><br><a href="/forgot-password">Şifremi Unuttum</a>

                    </p>
                </div>
            </div>
        </div>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/healthplusturkey/public_html/aesthplusturkey.com/resources/views/auth/login.blade.php ENDPATH**/ ?>