<?php $__env->startSection('title',' - Doktorlar'); ?>
<?php $__env->startSection('modulecontent'); ?>


    <div class="portlet-box">
        <div class="portlet-header flex-row flex d-flex align-items-center">
            <a href="/solaris/add/<?php echo e($module); ?>" class="btn btn-rounded btn-primary btn-sm">Yeni Ekle</a>

        </div>
        <div class="portlet-body no-padding">
            <table class="table table-striped mb-0 table-sm">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Başlık</th>
                    <th>Kategorisi</th>
                    <th>2. Kategorisi</th>
                    <th>Admin</th>
                    <th>Yayın Tarihi</th>
                    <th>İç Resim</th>
                    <th></th>
                </tr>
                </thead>
                <tbody>
                <?php ($f=0); ?>
                <?php $__currentLoopData = $cData->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($f++); ?>
                    <tr id="dat-<?php echo e($val->id); ?>">
                        <th scope="row"><?php echo e($val->id); ?></th>
                        <td><a href="/<?php echo e(str_slug($val->title,"-")); ?>/<?php echo e($val->id); ?>.html" target="_blank"><?php echo e($val->title); ?></a></td>
                        <td><?php if(isset($val->category->title)): ?><?php echo e($val->category->title); ?><?php endif; ?></td>
                        <td><?php if(isset($val->category2->title)): ?><?php echo e($val->category2->title); ?><?php endif; ?></td>
                        <td><?php echo e($val->user->name); ?></td>
                        <td><?php echo e($val->publish_time); ?></td>
                        <td><?php if(substr_count($val->description,"<input")>0): ?> <span class="fa fa-chevron-up"></span><?php endif; ?></td>
                        <td>
                            <a href="/solaris/doctors/edit/<?php echo e($val->id); ?>"  class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                            <a style="float: right;" onclick="sil('<?php echo e(Crypt::encryptString(json_encode(array("sID"=>$val->id,"func"=>"doctor","method"=>"destroy")))); ?>',<?php echo e($val->id); ?>)" class="btn btn-danger btn-sm"><i class="fas fa-times"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($cData->data)==0): ?>
                    <tr>
                        <th scope="row" colspan="5" class="text-center">Kayıtlı veri yok</th>

                    </tr>
                <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('solaris.module', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/healthplusturkey/public_html/aesthplusturkey.com/resources/views/solaris/doctors.blade.php ENDPATH**/ ?>