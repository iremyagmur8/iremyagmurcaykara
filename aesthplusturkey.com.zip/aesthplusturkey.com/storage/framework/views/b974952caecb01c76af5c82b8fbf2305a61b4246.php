<?php

function sanitize_output($buffer)
{

    $search = array(
        '/\>[^\S ]+/s',     // strip whitespaces after tags, except space
        '/[^\S ]+\</s',     // strip whitespaces before tags, except space
        '/(\s)+/s',         // shorten multiple whitespace sequences
        '/<!--(.|\s)*?-->/' // Remove HTML comments
    );

    $replace = array(
        '>',
        '<',
        '\\1',
        ''
    );

    $buffer = preg_replace($search, $replace, $buffer);

    return $buffer;
}

ob_start("sanitize_output");

?><!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <meta name="description" content="<?php echo $__env->yieldContent('desc'); ?>">
    <link rel="manifest" href="/icons/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="theme-color" content="#ffffff">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Document title -->
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="/assetWeb/asweb/fonts/boxicons/css/boxicons.min.css"/>

    <!--Iconsmind Icons-->
    <link rel="stylesheet" href="/assetWeb/asweb/fonts/iconsmind/iconsmind.css"/>
    <link rel="stylesheet" href="/solarisv2/vendor/css/simplebar.min.css">
    <link href="/assetWeb/asweb/css/theme.min.css" rel="stylesheet"/>
    <link href="/custom.css?v=<?php echo e(rand(0,999)); ?>" rel="stylesheet">
    <script src="/assetWeb/polo/js/jquery.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/lazyload@2.0.0-rc.2/lazyload.js"></script>
    <link rel="stylesheet" href="/assetWeb/asweb/vendor/node_modules/css/choices.min.css">
    <link rel="stylesheet" href="/assetWeb/asweb/vendor/node_modules/css/splitting.css">
    <!--Swiper slider-->
    <link rel="stylesheet" href="/assetWeb/asweb/vendor/node_modules/css/swiper-bundle.min.css"/>
    <!-- Aos Animations CSS -->
    <link rel="stylesheet" href="/assetWeb/asweb/vendor/node_modules/css/prism-tomorrow.css">
    <link href="/assetWeb/asweb/vendor/node_modules/css/aos.css" rel="stylesheet">

    <?php if(isset($amp)): ?>
        <link rel="amphtml" href="<?php echo e($amp); ?>"/> <?php endif; ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-LGQX9DK15V"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }

        gtag('js', new Date());
        gtag('config', 'G-LGQX9DK15V');
    </script>

    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8941717516585426"
            crossorigin="anonymous"></script>


</head>

<body>

<div class="spinner-loader bg-tint-primary">
    <div class="spinner-border text-primary" role="status">
    </div>
    <span class="small d-block ms-2">Loading...</span>
</div>
<header class="z-index-fixed header-absolute-top header-dark">
    <nav class="navbar navbar-expand-lg navbar-dark shadow-lg">
        <div class="container position-relative">
            <a class="navbar-brand" href="/">
                <img src="/images/logo.png" alt="" class="img-fluid navbar-brand-sticky">
            </a>
            <div class="d-flex align-items-center navbar-no-collapse-items order-lg-last">
                <button class="navbar-toggler order-last" type="button" data-bs-toggle="collapse"
                        data-bs-target="#mainNavbarTheme" aria-controls="mainNavbarTheme" aria-expanded="false"
                        aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon">
                                <i></i>
                            </span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="mainNavbarTheme">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a href="/" aria-haspopup="true"
                           aria-expanded="false" data-bs-auto-close="outside"
                           class="nav-link">
                            Anasayfa</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true"
                           aria-expanded="false" data-bs-auto-close="outside"
                           class="nav-link dropdown-toggle">
                            Tıbbi Kadro</a>
                        <div class="dropdown-menu">
                            <?php $__currentLoopData = $vars->doctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="dropend">
                                        <a class="dropdown-item"
                                           href=" <?php if($val->link): ?><?php echo e($val->link); ?><?php else: ?><?php echo e("/tibbi-kadro/".str_slug($val->title,"-")."/".$val->id.".htm"); ?><?php endif; ?>"><?php echo e($val->title); ?></a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </li>
                    <?php $__currentLoopData = $vars->menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item <?php if(count($val->childs)>0): ?> dropdown <?php endif; ?>"
                            <?php if(request("page") and request("page")==$val->id): ?> class="active" <?php endif; ?>>
                            <?php if(count($val->childs)>0): ?>
                                <a href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true"
                                   aria-expanded="false" data-bs-auto-close="outside"
                                   class="nav-link text-<?php if(isset($color)): ?><?php echo e($color); ?><?php endif; ?> dropdown-toggle">
                                    <?php echo e($val->title); ?></a>
                            <?php else: ?>
                                <a href=" <?php if($val->link): ?><?php echo e($val->link); ?><?php else: ?><?php echo e("/".str_slug($val->title,"-")."/".$val->id.".htm"); ?><?php endif; ?>"
                                   class="nav-link text-<?php if(isset($color)): ?><?php echo e($color); ?><?php endif; ?> ">
                                    <?php echo e($val->title); ?></a>
                            <?php endif; ?>
                        <!--Dropdown-->
                            <?php if(count($val->childs)>0): ?>
                                <div class="dropdown-menu">
                                    <?php $__currentLoopData = $val->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tKey=>$tVal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="dropend">
                                            <?php if(count($tVal->childs)>0): ?>
                                                <a class="dropdown-item dropdown-toggle" data-bs-toggle="dropdown"
                                                   href="#"><?php echo e($tVal->title); ?></a>
                                                <div class="dropdown-menu">
                                                    <?php $__currentLoopData = $tVal->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fKey=>$fVal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <a class="dropdown-item"
                                                           href="<?php if($fVal->link): ?><?php echo e($fVal->link); ?><?php else: ?><?php echo e("/".str_slug($fVal->title,"-")."/".$fVal->id.".htm"); ?><?php endif; ?>"><?php echo e($fVal->title); ?></a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            <?php else: ?>

                                                <a class="dropdown-item"

                                                   href="<?php if($tVal->link): ?><?php echo e($tVal->link); ?><?php else: ?><?php echo e("/".str_slug($tVal->title,"-")."/".$tVal->id.".htm"); ?><?php endif; ?>"><?php echo e($tVal->title); ?></a>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </nav>
</header>
<div class="container m-t-5 m-b-5">

    <!-- Neuesmodelauto yatay -->
    <ins class="adsbygoogle"
         style="display:block"
         data-ad-client="ca-pub-8941717516585426"
         data-ad-slot="2772544590"
         data-ad-format="auto"
         data-full-width-responsive="true"></ins>
    <script>
        (adsbygoogle = window.adsbygoogle || []).push({});
    </script>

</div>
<?php echo $__env->yieldContent("content"); ?>

<footer id="footer" class="bg-white">
    <div class="container pt-9 pt-lg-11 pb-5">
        <div class="row">
            <div class="col-sm-7 mb-4 mb-sm-0">
                <!--Address-->
                <h5 class="mb-0">
                    <?php echo nl2br(str_replace(" ", " &nbsp;", $vars->contact->address)); ?></h5>
            </div>
            <div class="col-sm-5 text-sm-end">
                <!--Phone-->
                <a href="tel:<?php echo e($vars->contact->phone); ?>"
                   class="fs-6 link-hover-underline"><?php echo e($vars->contact->phone); ?></a><br><br>
                <!--Email-->
                <a href="mailto:<?php echo e($vars->contact->mail); ?>" class="fs-6 link-hover-underline"><?php echo e($vars->contact->mail); ?></a>
            </div>
        </div>
        <hr class="my-4 my-md-5">
        <div class="row text-secondary">
            <div class="col-sm-7">
                <!--Social List-->
                <ul class="list-inline">
                    <?php if(isset($vars->contact->facebook)): ?>
                        <li class="list-inline-item">
                            <a class="link-hover-underline" target="_blank"
                               href="<?php echo e($vars->contact->facebook); ?>">Facebook</a>
                        </li>
                    <?php endif; ?>
                    <?php if(isset($vars->contact->twitter)): ?>
                        <li class="list-inline-item">
                            <a class="link-hover-underline" target="_blank"
                               href="<?php echo e($vars->contact->twitter); ?>">Twitter</a>
                        </li>
                    <?php endif; ?>

                    <?php if(isset($vars->contact->linkedin)): ?>
                        <li class="list-inline-item">
                            <a class="link-hover-underline" target="_blank"
                               href="<?php echo e($vars->contact->linkedin); ?>">Linkedin</a>
                        </li>
                    <?php endif; ?>

                    <?php if(isset($vars->contact->instagram)): ?>
                        <li class="list-inline-item">
                            <a class="link-hover-underline" target="_blank" href="<?php echo e($vars->contact->instagram); ?>">Instagram</a>
                        </li>
                    <?php endif; ?>

                </ul>
            </div>
            <div class="col-sm-5 text-sm-end">
                <!--Copyright Text-->
                <span class="d-block lh-sm small text-muted">© Copyright
                    <script>
                      document.write(new Date().getFullYear())
                    </script>. Aesthplusturkey
                  </span>
            </div>
        </div>
    </div>
</footer>


<script src="/assetWeb/asweb/js/theme.bundle.js"></script>
<script src="/assetWeb/asweb/vendor/node_modules/js/choices.min.js"></script>
<script>
    var cSelect = document.querySelectorAll("[data-choices]");
    cSelect.forEach(el => {
        const t = {
            ...el.dataset.choices ? JSON.parse(el.dataset.choices) : {},
            ...{
                classNames: {
                    containerInner: el.className,
                    input: "form-control",
                    inputCloned: "form-control-sm",
                    listDropdown: "dropdown-menu",
                    itemChoice: "dropdown-item",
                    activeState: "show",
                    selectedState: "active"
                }
            }
        }
        new Choices(el, t)
    });

</script>
<script src="/assetWeb/asweb/vendor/node_modules/js/swiper-bundle.min.js"></script>
<script>
    //swiper -partners
    var swiperPartners5 = new Swiper(".swiper-partners-5", {
        slidesPerView: 3,
        loop: true,
        spaceBetween: 16,
        autoplay: true,
        breakpoints: {
            768: {
                slidesPerView: 4,
            },
            1024: {
                slidesPerView: 5,
            },
        },
        pagination: {
            el: ".swiper-partners-5-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-partners-5-button-next",
            prevEl: ".swiper-partners-5-button-prev",
        },
    });
    //swiper-Testimonials
    var swiper3 = new Swiper(".swiper-quotes", {
        loop: true,
        grabCursor: true,
        speed: 600,
        autoHeight: true,
        navigation: {
            nextEl: ".swiperTestimonials-button-next",
            prevEl: ".swiperTestimonials-button-prev",
        },
    });
    var swiper = new Swiper(".swiper-people", {
        spaceBetween: 0,
        effect: "fade",
        loop: true,
        grabCursor: true,
        speed: 600,
    });
    // Link together the navigation of both swipers
    var swiperQuotes = document.querySelector('.swiper-quotes').swiper
    var swiperPeople = document.querySelector('.swiper-people').swiper

    swiperQuotes.controller.control = swiperPeople
    swiperPeople.controller.control = swiperQuotes

    //Swiper for text/headings
    var swiperText = new Swiper(".swiper-text", {
        autoplay: true,
        direction: "vertical",
        loop: true,
        grabCursor: false,
        speed: 600,
        autoHeight: true,
    });
    //Swiper for text/headings
    var swiperFade = new Swiper(".swiper-feature-img", {
        autoplay: true,
        loop: true,
        grabCursor: false,
        speed: 600
    });
    // Link together the navigation of both swipers
    var swiperText = document.querySelector('.swiper-text').swiper
    var swiperFeatureImage = document.querySelector('.swiper-feature-img').swiper

    swiperText.controller.control = swiperFeatureImage
    swiperFeatureImage.controller.control = swiperText

</script>
<!--Template functions-->
<script src="/js/solaris.js?v=<?php echo e(rand(0,99999999999999)); ?>"></script>
<script type="text/javascript" charset="utf-8">
    $(function () {
        $(".lazys").lazyload({
            effect: "fadeIn",
            event: "scroll"
        });
    });
</script>
</body>

</html><?php ob_end_flush();?>
<?php /**PATH /home/healthplusturkey/public_html/aesthplusturkey.com/resources/views/layouts/app.blade.php ENDPATH**/ ?>