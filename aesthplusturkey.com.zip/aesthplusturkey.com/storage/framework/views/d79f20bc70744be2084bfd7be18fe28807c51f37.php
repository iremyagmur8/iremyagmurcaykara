<?php $__env->startSection('title','Auto-Neuheiten 2021, 2022, 2023: Alle neuen Modelle der letzten Zeit'); ?>
<?php $__env->startSection('desc',''); ?>
<?php $__env->startSection('content'); ?>
    <?php
        use App\Http\Controllers\HomepageController
    ?>
    <section class="content background-grey">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $cData->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->iteration == 0) continue; ?>
                    <div class="col-md-4">

                        <?php echo $__env->make("inc.postBox",['bVal'=>$val,"height"=>200,"desc"=>0,"title"=>1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                    </div>
                    <?php if($loop->iteration == 3) break; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>


            <?php $f=3; ?>
            <div class="row ">
                <div class="col-md-8">
                    <a href="/<?php echo e(str_slug($cData->data[$f]->title,"-")); ?>/<?php echo e($cData->data[$f]->id); ?>.html" class="alink">
                        <div class="manset lazys" data-src="<?php echo e(HomepageController::webps($cData->data[$f]->files[0]->file,"l")); ?>"
                             style="background:url('<?php if(isset($cData->data[$f]->files[0]->file)): ?><?php echo e(HomepageController::webps($cData->data[$f]->files[0]->file,"l")); ?><?php endif; ?>') center center; background-size:cover"></div>
                        <span><?php echo e($cData->data[$f]->title); ?></span>
                    </a>
                </div>
                <div class="col-md-4">
                    <?php $f=4; ?>
                    <a href="/<?php echo e(str_slug($cData->data[$f]->title,"-")); ?>/<?php echo e($cData->data[$f]->id); ?>.html" class="alink">
                        <div class="mansetright  lazys" data-src="<?php echo e(HomepageController::webps($cData->data[$f]->files[0]->file,"l")); ?>"
                             style="background:url('<?php if(isset($cData->data[$f]->files[0]->file)): ?><?php echo e(HomepageController::webps($cData->data[$f]->files[0]->file,"m")); ?><?php endif; ?>') center center; background-size:cover"></div>
                        <span class="font14"><?php echo e($cData->data[$f]->title); ?></span></a>
                    <?php $f=5; ?>
                    <a href="/<?php echo e(str_slug($cData->data[$f]->title,"-")); ?>/<?php echo e($cData->data[$f]->id); ?>.html"
                       class="alink mt10">
                        <div class="mansetright lazys"  data-src="<?php echo e(HomepageController::webps($cData->data[$f]->files[0]->file,"l")); ?>"
                             style="background:url('<?php if(isset($cData->data[$f]->files[0]->file)): ?><?php echo e(HomepageController::webps($cData->data[$f]->files[0]->file,"m")); ?><?php endif; ?>') center center; background-size:cover"></div>
                        <span class="font14"><?php echo e($cData->data[$f]->title); ?></span></a>
                </div>
            </div>
            <div class="row mt10">
                <div class="col-md-5" style="padding-right: 0px">
                    <?php $f=6; ?>
                    <?php echo $__env->make("inc.postBox",['bVal'=>$cData->data[$f],"height"=>300], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
                <div class="col-md-7">
                    <div class="row" style="padding-left: 15px; padding-right: 15px; ">
                        <div class="col-md-6">
                            <?php $f=7; ?>
                            <?php echo $__env->make("inc.postBox",['bVal'=>$cData->data[$f],"title"=>1,"desc"=>0,"height"=>150], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <?php $f=8; ?>
                            <?php echo $__env->make("inc.postBox",['bVal'=>$cData->data[$f],"title"=>1,"desc"=>0,"height"=>150], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>


                        <div class="col-md-6">

                            <?php $f=9; ?>
                            <?php echo $__env->make("inc.postBox",['bVal'=>$cData->data[$f],"title"=>1,"desc"=>0,"height"=>150], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <?php $f=10; ?>
                            <?php echo $__env->make("inc.postBox",['bVal'=>$cData->data[$f],"title"=>1,"desc"=>0,"height"=>150], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-8" style="
    padding-right: 15px;
    padding-left: 15px;
">
                    <div class="row">
                        <?php $__currentLoopData = $cData->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($loop->iteration > 11): ?>
                                <div class="col-md-6">


                                    <?php echo $__env->make("inc.postBox",['bVal'=>$val,"title"=>1,"height"=>200,'desc'=>1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                </div>

                                <?php if($loop->iteration % 3 == 0): ?>
                                    <div class="col-md-6">

                                        <!-- neuesmodelauto kare -->
                                        <ins class="adsbygoogle"
                                             style="display:block"
                                             data-ad-client="ca-pub-8941717516585426"
                                             data-ad-slot="7174824032"
                                             data-ad-format="auto"
                                             data-full-width-responsive="true"></ins>
                                        <script>
                                            (adsbygoogle = window.adsbygoogle || []).push({});
                                        </script>
                                    </div>
                                <?php endif; ?>


                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>


                </div>
                <?php echo $__env->make("home.sidebar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            </div>


        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/healthplusturkey/public_html/resources/views/home/index.blade.php ENDPATH**/ ?>