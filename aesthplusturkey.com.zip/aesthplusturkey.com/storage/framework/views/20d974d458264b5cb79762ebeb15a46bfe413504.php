<?php
    $padding=$padding. "&nbsp;&nbsp;&nbsp;";
?>
<?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <option value="<?php echo e($child->id); ?>"
            <?php if(!empty($cData->data) && ($cData->data->parent_id == $child->id or $cData->data->category_id == $child->id)): ?> selected <?php endif; ?>><?php echo $padding; ?><?php echo e($child->title); ?></option>
    <?php if(count($child->childs)): ?>
        <?php if(!empty($cData->data)): ?>
            <?php echo $__env->make('solaris.categories.subCategories',['childs' => $child->childs,'padding'=> $padding,'cData'=>$cData], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make('solaris.categories.subCategories',['childs' => $child->childs,'padding'=> $padding], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php /**PATH /home/healthplusturkey/public_html/resources/views/solaris/categories/subCategories.blade.php ENDPATH**/ ?>