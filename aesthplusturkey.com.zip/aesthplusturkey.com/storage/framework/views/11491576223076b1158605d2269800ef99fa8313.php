<?php $__env->startSection('title',' - Banner Ekle'); ?>
<?php $__env->startSection('modulecontent'); ?>


    <div class="portlet-box">

        <div class="portlet-header flex-row flex d-flex align-items-center">
            <a href="/solaris/add/banners" class="btn btn-rounded btn-primary btn-sm m-r-5">Formu
                Sıfırla</a>
            <a href="/solaris/banners" class="btn btn-rounded btn-danger btn-sm">Tüm İçerikler</a>
        </div>

        <form class="form-horizontal dropzone" method="POST" action="/solaris/addbanners" id="formData"
              enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php if(!empty($cData->data)): ?> <input type="hidden" name="degisID" value="<?php echo e($cData->data->id); ?>"> <?php endif; ?>

        <div class="col-md-12">


            <input type="hidden" name="type" value="3">


            <div class="row">
                <div class="form-group col-md-6">
                    <label for="title">Adı Soyadı</label>
                    <input type="text" class="form-control" name="title"
                           value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->title); ?><?php endif; ?>"
                           autofocus>
                </div>
                <div class="form-group col-md-6">
                    <label for="title">Button Text</label>
                    <input type="text" class="form-control" name="buttontext"
                           value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->buttontext); ?><?php endif; ?>"
                           autofocus>
                </div>
                <!--
                <div class="form-group col-md-6">
                    <label for="title">Kurul Türü</label>

                    <select class="form-control" name="kurulturu">
                        <option value="0">Lütfen Seçin</option>
                        <option value="YÖNETİM KURULU" <?php if(!empty($cData->data) && $cData->data->kurulturu == "YÖNETİM KURULU"): ?> selected <?php endif; ?>>YÖNETİM KURULU</option>
                        <option value="DENETİM KURULU" <?php if(!empty($cData->data) && $cData->data->kurulturu == "DENETİM KURULU"): ?> selected <?php endif; ?>>DENETİM KURULU</option>
                        <option value="DİSİPLİN KURULU" <?php if(!empty($cData->data) && $cData->data->kurulturu == "DİSİPLİN KURULU"): ?> selected <?php endif; ?>>DİSİPLİN KURULU</option>
                    </select>

                </div>
                -->



            </div>

            <div class="form-row">

                <div class="form-group col-md-4">
                    <label for="title">Yer</label>
                    <input type="text" class="form-control" name="place"
                           value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->place); ?><?php endif; ?>"
                           autofocus>
                </div>

                <div class="form-group col-md-4">
                    <label for="title">Sıra</label>
                    <input type="text" class="form-control" name="sort"
                           value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->sort); ?><?php endif; ?>"
                           autofocus>
                </div>




                <div class="form-group col-md-4">
                    <label for="title">Video Embed</label>
                    <input type="text" class="form-control" name="video"
                           value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->video); ?><?php endif; ?>"
                           autofocus>
                </div>

                <div class="form-group col-md-12">
                    <label for="title">Kısa Açıklama</label>
                    <textarea  class="form-control" name="shortdescription"  autofocus><?php if(!empty($cData->data)): ?><?php echo e($cData->data->shortdescription); ?><?php endif; ?></textarea>
                </div>

            </div>

            <div class="form-row">

                <div class="form-group col-md-12">
                        <textarea class="form-control" id="summary-ckeditor"
                                  name="description"><?php if(!empty($cData->data)): ?><?php echo e($cData->data->description); ?><?php endif; ?></textarea>
                </div>

                <div class="form-group col-md-12">
                    <label for="document">Dosyalar</label>
                    <input type="file"
                           class="filepond"
                           name="file[]"
                           multiple
                           data-allow-reorder="true">
                </div>

            </div>

            <div class="form-group">
                <div class="col-md-12 text-center">
                    <button type="submit" class="btn btn-primary">
                        Kaydet
                    </button>
                </div>
            </div>


        </div>


        </form>


    </div>



    <script src="//cdn.ckeditor.com/4.14.0/full/ckeditor.js"></script>
    <script>

        CKEDITOR.replace('summary-ckeditor', {
            filebrowserUploadUrl: "<?php echo e(route('ckupload', ['_token' => csrf_token() ])); ?>",
            filebrowserUploadMethod: 'form',
            height: 500
        });

        FilePond.registerPlugin(
            FilePondPluginImageCrop,
            FilePondPluginImagePreview,
            FilePondPluginFilePoster
        );

        // Get a reference to the file input element
        const inputElement = document.querySelector('.filepond');

        // Create the FilePond instance
        const pond = FilePond.create(inputElement, {
            allowImageEdit: true,
            labelIdle: 'Sürükle ya da <span class="filepond--label-action"> seç </span>',
            styleImageEditButtonEditItemPosition: 'bottom',
            imageCropAspectRatio: '1:1',
            onreorderfiles: (files, origin, target) => {
                var images = []
                files.forEach(element => {
                    images.push(element.file.name)
                });
                $.ajax({
                    method: "POST",
                    url: "/solaris/sortfiles",
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    data: {file: images}
                })
                    .done(function (msg) {
                        console.log(msg);
                    });

            },
            server: {
                url: '/filepond/api',
                process: '/process',

                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                load: (source, load, error, progress, abort, headers) => {
                    var request = new Request(source);
                    fetch(request).then(function (response) {
                        response.blob().then(function (myBlob) {
                            load(myBlob)
                        });
                    });

                },

                remove: (source, load, error, options) => {
                    console.log(source);
                    console.log(options);

                    $.ajax({
                        method: "POST",
                        url: "/solaris/deletefile",
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        data: {file: source}
                    })
                        .done(function (msg) {
                            console.log(msg);
                        });
                    load();


                },

            }
            <?php if(isset($cData->data)): ?>
            , files: [
                    <?php $__currentLoopData = $cData->data->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    source: '<?php echo e(config('solaris.site.url').Storage::url("/images/userfiles/".$val->file)); ?>',
                    options: {
                        type: 'local',

                    },
                    metadata: {
                        poster: '<?php echo e(config('solaris.site.url').Storage::url("/images/userfiles/".$val->file)); ?>'
                    }
                }
                <?php if(!$loop->last): ?> , <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],

            <?php endif; ?>

        });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('solaris.module', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/karip/public_html/laravel-neuesmodelauto/resources/views/solaris/create-banners.blade.php ENDPATH**/ ?>