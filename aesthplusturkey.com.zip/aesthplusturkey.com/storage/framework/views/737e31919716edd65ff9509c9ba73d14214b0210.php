<?php $__env->startSection('title',' - Doktor Ekle'); ?>
<?php $__env->startSection('modulecontent'); ?>


    <div class="portlet-box">
        <div class="portlet-header flex-row flex d-flex align-items-center">
            <a href="/solaris/add/doctors" class="btn btn-rounded btn-primary btn-sm m-r-5">Formu
                Sıfırla</a>
            <a href="/solaris/<?php echo e(request("module")); ?>" class="btn btn-rounded btn-danger btn-sm">Tüm Doktorlar</a>
        </div>


        <form class="form-horizontal dropzone" method="POST" action="/solaris/adddoctor" id="formData"
              enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php if(!empty($cData->data)): ?> <input type="hidden" name="degisID" value="<?php echo e($cData->data->id); ?>"> <?php endif; ?>
            <div class="col-md-12">

                <div class="form-row">
                    <div class="form-group col-md-8">
                        <label for="title">Doktor Ad-Soyad</label>
                        <input type="text" class="form-control" name="title"
                               value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->title); ?><?php endif; ?>"
                               autofocus>
                    </div>


                    <div class="form-group col-md-4">
                        <label for="buttontext">Button Text</label>
                        <input type="text" class="form-control" name="buttontext"
                               value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->buttontext); ?><?php endif; ?>"
                               autofocus>
                    </div>

                </div>
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label for="title">Kısa Açıklama</label>
                        <textarea class="form-control" name="shortdescription"
                                  autofocus><?php if(!empty($cData->data)): ?><?php echo e($cData->data->shortdescription); ?><?php endif; ?></textarea>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="bannertitle">Banner Başlık</label>
                        <input type="text" class="form-control" name="bannertitle"
                               value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->bannertitle); ?><?php endif; ?>"
                               autofocus>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="bannerdescription">Banner Açıklama</label>
                        <textarea class="form-control" name="bannerdescription" rows="1"
                                  autofocus><?php if(!empty($cData->data)): ?><?php echo e($cData->data->bannerdescription); ?><?php endif; ?></textarea>
                    </div>
                </div>
                <div class="form-row">

                    <div class="form-group col-md-2">
                        <label for="title">Sıra</label>
                        <input type="text" class="form-control" name="sort"
                               value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->sort); ?><?php endif; ?>"
                               autofocus>
                    </div>

                    <div class="form-group col-md-2">
                        <label for="type">İçerik Teması</label>
                        <select class="form-control" name="theme" id="theme">
                            <option value="0">
                                Lütfen Seçin
                            </option>
                            <option value="1" <?php if(!empty($cData->data) && $cData->data->theme == 1): ?> selected <?php endif; ?>>Tema
                                1
                            </option>
                            <option value="2" <?php if(!empty($cData->data) && $cData->data->theme == 2): ?> selected <?php endif; ?>>Tema
                                2
                            </option>
                            <option value="3" <?php if(!empty($cData->data) && $cData->data->theme == 3): ?> selected <?php endif; ?>>Tema
                                3
                            </option>
                            <option value="4" <?php if(!empty($cData->data) && $cData->data->theme == 4): ?> selected <?php endif; ?>>Tema
                                4
                            </option>
                            <option value="5" <?php if(!empty($cData->data) && $cData->data->theme == 5): ?> selected <?php endif; ?>>Tema
                                5
                            </option>
                        </select>
                    </div>

                    <div class="form-group col-md-4">
                        <label for="title">Link</label>
                        <input type="text" class="form-control" name="link"
                               value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->link); ?><?php endif; ?>"
                               autofocus>
                    </div>


                    <div class="form-group col-md-2">
                        <label for="title">Etiketler</label>
                        <input type="text" class="form-control" name="tag"
                               value="<?php if(!empty($cData->data)): ?><?php echo e($cData->data->tag); ?><?php endif; ?>"
                               autofocus>
                    </div>

                    <div class="form-group col-md-2">
                        <label for="title">Yayın Tarihi</label>
                        <input type="datetime-local" class="form-control" name="publishtime"
                               value="<?php if(!empty($cData->data)): ?><?php echo e(date("Y-m-d",strtotime($cData->data->publish_time))); ?>T<?php echo e(date("H:i",strtotime($cData->data->publish_time))); ?><?php else: ?><?php echo e(date("Y-m-d")."T".date("H:i")); ?><?php endif; ?>"
                               autofocus>
                    </div>


                    <div class="form-group col-md-12">
                        <textarea class="form-control" id="summary-ckeditor"
                                  name="description"><?php if(!empty($cData->data)): ?><?php echo e($cData->data->description); ?><?php endif; ?></textarea>
                    </div>


                    <div class="form-group col-md-12">
                        <label for="document">Dosyalar</label>
                        <input type="file"
                               class="filepond"
                               name="file[]"
                               multiple
                               data-allow-reorder="true">
                    </div>


                    <div class="form-group">
                        <div class="col-md-12 text-center">
                            <button type="submit" class="btn btn-primary">
                                Kaydet
                            </button>
                        </div>
                    </div>

                </div>


            </div>


        </form>

    </div>



    <script src="//cdn.ckeditor.com/4.14.0/full/ckeditor.js"></script>
    <script>

        CKEDITOR.replace('summary-ckeditor', {
            filebrowserUploadUrl: "/ckeditor/image_upload?_token=<?php echo e(csrf_token()); ?>",
            filebrowserUploadMethod: 'form',
            height: 500
        });

        FilePond.registerPlugin(
            FilePondPluginImageCrop,
            FilePondPluginImagePreview,
            FilePondPluginFilePoster
        );

        // Get a reference to the file input element
        const inputElement = document.querySelector('.filepond');

        // Create the FilePond instance
        const pond = FilePond.create(inputElement, {
            allowImageEdit: true,
            labelIdle: 'Sürükle ya da <span class="filepond--label-action"> seç </span>',
            styleImageEditButtonEditItemPosition: 'bottom',
            imageCropAspectRatio: '1:1',
            onreorderfiles: (files, origin, target) => {
                var images = []
                files.forEach(element => {
                    images.push(element.file.name)
                });
                $.ajax({
                    method: "POST",
                    url: "/solaris/sortfiles",
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                    },
                    data: {file: images}
                })
                    .done(function (msg) {
                        console.log(msg);
                    });

            },
            server: {
                url: '/filepond/api',
                process: '/process',

                headers: {
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                load: (source, load, error, progress, abort, headers) => {
                    var request = new Request(source);
                    fetch(request).then(function (response) {
                        response.blob().then(function (myBlob) {
                            load(myBlob)
                        });
                    });

                },

                remove: (source, load, error, options) => {
                    console.log(source);
                    console.log(options);

                    $.ajax({
                        method: "POST",
                        url: "/solaris/deletefile",
                        headers: {
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        data: {file: source}
                    })
                        .done(function (msg) {
                            console.log(msg);
                        });
                    load();


                },

            }
            <?php if(isset($cData->data)): ?>
            , files: [
                    <?php $__currentLoopData = $cData->data->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    source: '<?php echo e(config('solaris.site.url').Storage::url("images/userfiles/".$val->file)); ?>',
                    options: {
                        type: 'local',

                    },
                    metadata: {
                        poster: '<?php echo e(config('solaris.site.url').Storage::url("images/userfiles/".$val->file)); ?>'
                    }
                }
                <?php if(!$loop->last): ?> , <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],

            <?php endif; ?>

        });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('solaris.module', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/healthplusturkey/public_html/aesthplusturkey.com/resources/views/solaris/create-doctors.blade.php ENDPATH**/ ?>