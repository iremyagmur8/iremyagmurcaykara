<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomepageController;




Route::get('/',[HomepageController::class,'index'])->name('index');
Route::get('/tibbi-kadro/{title}/{id}.htm',[HomepageController::class,'team'])->name('team');
Route::get('/{title}/{id}.htm',[HomepageController::class,'post'])->name('post');


Route::get('amazon',[HomepageController::class,'amazon']);

Route::post('/api',[HomepageController::class,'api'])->name('api');

require __DIR__.'/auth.php';
require __DIR__.'/solaris.php';
